const axios = require('axios');
const cheerio = require('cheerio');
const commander = require('commander');
const fs = require('fs');
const path = require('path');

// Function to download an image
async function downloadImage(url, filePath) {
  const response = await axios.get(url, { responseType: 'stream' });
  const writer = fs.createWriteStream(filePath);

  return new Promise((resolve, reject) => {
    response.data.pipe(writer);
    writer.on('finish', resolve);
    writer.on('error', reject);
  });
}

// Function to recursively download images
async function downloadImagesRecursively(url, maxDepth, currentDepth, outputPath) {
  if (currentDepth > maxDepth) return;

  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    
    // Extract image URLs with specified extensions
    $('img').each(async (index, element) => {
      const imageUrl = $(element).attr('src');
      if (imageUrl && /\.(jpg|jpeg|png|gif|bmp)$/i.test(imageUrl)) {
        const imageName = path.basename(imageUrl);
        const imageFilePath = path.join(outputPath, imageName);
        await downloadImage(imageUrl, imageFilePath);
        console.log(`Downloaded: ${imageFilePath}`);
      }
    });

    // Recursively follow links and download images
    if (currentDepth < maxDepth) {
      const links = $('a').map((index, element) => $(element).attr('href')).get();
      for (const link of links) {
        if (link && link.startsWith('http')) {
          await downloadImagesRecursively(link, maxDepth, currentDepth + 1, outputPath);
        }
      }
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

commander
  .version('1.0.0')
  .option('-r, --recursive', 'Recursively download images from URL')
  .option('-l, --max-depth [N]', 'Maximum depth level of recursive download', parseInt, 5)
  .option('-p, --path [PATH]', 'Path to save downloaded files', './data/')
  .arguments('<url>')
  .parse(process.argv);

if (!commander.args[0]) {
  console.error('Please provide a URL as an argument.');
  process.exit(1);
}
const options =commander.opts()

const url = commander.args[0];
const outputPath = path.resolve(options.path);
if (!fs.existsSync(outputPath)) {
  fs.mkdirSync(outputPath, { recursive: true });
}

if (options.recursive) {
  console.log(`Recursively downloading images from URL: ${url}`);
  console.log(`Maximum depth level: ${options.maxDepth}`);
  console.log(`Path to save downloaded files: ${outputPath}`);
  downloadImagesRecursively(url, options.maxDepth, 0, outputPath);
} else {
  console.error('Please specify the -r option to enable recursive downloading.');
}
